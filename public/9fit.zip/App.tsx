import React, { useState } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { OnboardingFlow } from './components/Onboarding/OnboardingFlow';
import { Dashboard } from './components/Dashboard/Dashboard';
import { AppView, UserProfile } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.SPLASH);
  // Default profile for development if needed
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const handleSplashComplete = () => {
    setCurrentView(AppView.LOGIN);
  };

  const handleLogin = () => {
    setCurrentView(AppView.ONBOARDING);
  };

  const handleOnboardingComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    setCurrentView(AppView.DASHBOARD);
  };

  if (currentView === AppView.SPLASH) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  if (currentView === AppView.LOGIN) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  if (currentView === AppView.ONBOARDING) {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  if (currentView === AppView.DASHBOARD && userProfile) {
    return <Dashboard userProfile={userProfile} />;
  }

  // Fallback for Dashboard dev if profile is missing (should not happen in flow)
  return <Dashboard userProfile={{ goal: 'General Fitness', name: 'User' }} />;
};

export default App;
