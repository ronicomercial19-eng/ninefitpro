import React, { useState } from 'react';
import { QrCode, ShieldCheck, Activity } from 'lucide-react';

export const DigitalIDCard: React.FC = () => {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div className="perspective-1000 w-full h-56 cursor-pointer group" onClick={() => setIsFlipped(!isFlipped)}>
      <div className={`relative w-full h-full transition-transform duration-700 preserve-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
        
        {/* Front */}
        <div className="absolute inset-0 backface-hidden bg-black rounded-2xl border border-dark-700 overflow-hidden shadow-2xl">
          {/* Holographic Effect */}
          <div className="absolute inset-0 opacity-20 bg-gradient-to-tr from-purple-500 via-neon-400 to-blue-500 mix-blend-color-dodge animate-pulse-slow"></div>
          <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>

          <div className="relative z-10 p-6 flex flex-col justify-between h-full">
            <div className="flex justify-between items-start">
              <div>
                 <h3 className="text-neon-400 font-black italic text-2xl tracking-tighter">9FIT <span className="text-white text-xs not-italic font-normal tracking-widest border border-white px-1 ml-1">PRO</span></h3>
                 <p className="text-[10px] text-gray-400 uppercase tracking-[0.3em] mt-1">Global Access Pass</p>
              </div>
              <ShieldCheck className="text-neon-400" size={24} />
            </div>

            <div className="flex items-end justify-between">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gray-800 rounded-lg border-2 border-white/20 overflow-hidden">
                     {/* User Photo Placeholder */}
                     <div className="w-full h-full bg-gradient-to-br from-gray-700 to-black flex items-center justify-center">
                        <span className="text-xl">💀</span>
                     </div>
                  </div>
                  <div>
                     <p className="text-white font-bold uppercase tracking-wider text-sm">Operative #992</p>
                     <p className="text-[10px] text-gray-400 uppercase">Member since 2024</p>
                  </div>
               </div>
               <QrCode className="text-white opacity-80" size={48} />
            </div>
          </div>
        </div>

        {/* Back */}
        <div className="absolute inset-0 backface-hidden rotate-y-180 bg-dark-900 rounded-2xl border border-neon-400 overflow-hidden p-6 flex flex-col items-center justify-center text-center">
           <Activity size={48} className="text-neon-400 mb-4 animate-pulse" />
           <h3 className="text-white font-bold uppercase tracking-widest mb-2">Status: Active</h3>
           <p className="text-xs text-gray-500 max-w-[80%]">This digital credential grants access to all 9FIT operational zones and events.</p>
           <p className="mt-4 text-[10px] font-mono text-neon-400">ID: 882-991-XAA</p>
        </div>
      </div>
      
      <style>{`
        .preserve-3d { transform-style: preserve-3d; }
        .backface-hidden { backface-visibility: hidden; }
        .rotate-y-180 { transform: rotateY(180deg); }
        .perspective-1000 { perspective: 1000px; }
      `}</style>
    </div>
  );
};
