import React from 'react';
import { Hexagon, Zap, Shield, Activity, Settings } from 'lucide-react';
import { DigitalIDCard } from './DigitalIDCard';
import { SeasonPassView } from '../SeasonPass/SeasonPassView';

export const ProfileView: React.FC = () => {
  return (
    <div className="space-y-8 pb-24">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-black italic uppercase tracking-tighter text-white">Identity</h2>
        <Settings className="text-gray-500" size={20} />
      </div>

      {/* ID Card */}
      <DigitalIDCard />

      {/* Stats Hexagon */}
      <div className="bg-dark-900 border border-dark-700 p-6 relative">
         <div className="flex justify-between items-center mb-6">
            <h3 className="text-white font-bold uppercase tracking-wider text-sm">Attributes</h3>
            <span className="text-[10px] text-neon-400 bg-neon-400/10 px-2 py-1 rounded-full uppercase font-bold">Level 12</span>
         </div>
         
         <div className="grid grid-cols-3 gap-4 text-center">
            {[
               { label: 'Strength', val: 78, icon: <Shield size={16} /> },
               { label: 'Agility', val: 64, icon: <Activity size={16} /> },
               { label: 'Stamina', val: 82, icon: <Zap size={16} /> }
            ].map((stat) => (
               <div key={stat.label} className="flex flex-col items-center gap-2">
                  <div className="w-12 h-12 relative flex items-center justify-center">
                     <Hexagon className="text-dark-700 absolute inset-0 w-full h-full fill-dark-800" strokeWidth={1} />
                     <span className="relative z-10 text-white font-black">{stat.val}</span>
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-gray-500 uppercase font-bold">
                     {stat.icon} {stat.label}
                  </div>
               </div>
            ))}
         </div>
      </div>

      {/* Badges Collection */}
      <div>
         <h3 className="text-white font-bold uppercase tracking-wider text-sm mb-4">Collection</h3>
         <div className="flex gap-4 overflow-x-auto pb-2 hide-scrollbar">
            {[1, 2, 3, 4, 5].map((i) => (
               <div key={i} className={`w-16 h-16 rounded-lg flex-shrink-0 flex items-center justify-center border 
                  ${i <= 3 ? 'bg-dark-800 border-neon-400/30' : 'bg-black border-dark-800 opacity-50'}`}>
                  {i <= 3 ? <span className="text-2xl">🏆</span> : <LockIcon />}
               </div>
            ))}
         </div>
      </div>

      {/* Season Pass Integration */}
      <div className="pt-4 border-t border-dark-700">
         <SeasonPassView />
      </div>
    </div>
  );
};

const LockIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-700"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>;
