import React, { useState } from 'react';
import { Heart, MessageCircle, Trophy, TrendingUp } from 'lucide-react';
import { FeedPost, LeaderboardUser } from '../../types';

const POSTS: FeedPost[] = [
  { id: '1', user: 'Sarah Connor', avatar: 'SC', image: 'bg-blue-900', caption: 'Morning run completed. Zone 2 focus today.', likes: 24, timeAgo: '2h' },
  { id: '2', user: 'Mike Ross', avatar: 'MR', image: 'bg-orange-900', caption: 'New PR on deadlifts! 140kg moving easy.', likes: 82, timeAgo: '5h' },
];

const RANKING: LeaderboardUser[] = [
  { rank: 1, name: 'Alex Chen', xp: 12500, avatar: 'AC', change: 'same' },
  { rank: 2, name: 'You', xp: 11200, avatar: '💀', change: 'up' },
  { rank: 3, name: 'Jordan B.', xp: 10800, avatar: 'JB', change: 'down' },
];

export const SocialView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'FEED' | 'RANK'>('FEED');

  return (
    <div className="space-y-6 pb-24">
      {/* Header Toggle */}
      <div className="flex bg-dark-800 p-1 rounded-lg border border-dark-700">
        <button 
          onClick={() => setActiveTab('FEED')}
          className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-md transition-all ${activeTab === 'FEED' ? 'bg-neon-400 text-black' : 'text-gray-500'}`}
        >
          Community Feed
        </button>
        <button 
          onClick={() => setActiveTab('RANK')}
          className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-md transition-all ${activeTab === 'RANK' ? 'bg-neon-400 text-black' : 'text-gray-500'}`}
        >
          Global Ranking
        </button>
      </div>

      {activeTab === 'FEED' ? (
        <div className="space-y-6 animate-slide-up">
          {POSTS.map(post => (
            <div key={post.id} className="bg-dark-900 border border-dark-700 rounded-sm overflow-hidden group">
              <div className="p-4 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-xs font-bold text-white border border-gray-600">
                  {post.avatar}
                </div>
                <div>
                  <p className="text-sm font-bold text-white">{post.user}</p>
                  <p className="text-[10px] text-gray-500 uppercase">{post.timeAgo} ago</p>
                </div>
              </div>
              
              <div className={`w-full h-64 ${post.image} relative`}>
                 <div className="absolute inset-0 bg-black/20"></div>
                 <div className="absolute bottom-4 left-4 right-4">
                    <p className="text-white text-sm drop-shadow-md">{post.caption}</p>
                 </div>
              </div>

              <div className="p-4 flex items-center gap-6 border-t border-white/5">
                <button className="flex items-center gap-2 text-gray-400 hover:text-neon-400 transition-colors">
                   <Heart size={18} /> <span className="text-xs font-bold">{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                   <MessageCircle size={18} /> <span className="text-xs font-bold">Comment</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-2 animate-slide-up">
           {RANKING.map((user) => (
             <div key={user.rank} className={`flex items-center justify-between p-4 border rounded-sm ${user.name === 'You' ? 'bg-neon-400/10 border-neon-400' : 'bg-dark-800 border-dark-700'}`}>
                <div className="flex items-center gap-4">
                   <div className="w-8 flex justify-center font-black text-lg italic text-gray-500">
                      {user.rank <= 3 ? <Trophy size={20} className={user.rank === 1 ? 'text-yellow-400' : user.rank === 2 ? 'text-gray-300' : 'text-orange-400'} /> : user.rank}
                   </div>
                   <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center text-sm border border-gray-600">
                      {user.avatar}
                   </div>
                   <div>
                      <p className={`text-sm font-bold uppercase ${user.name === 'You' ? 'text-neon-400' : 'text-white'}`}>{user.name}</p>
                      <p className="text-[10px] text-gray-500 font-mono">{user.xp} XP</p>
                   </div>
                </div>
                {user.change === 'up' && <TrendingUp size={16} className="text-neon-400" />}
             </div>
           ))}
        </div>
      )}
    </div>
  );
};
