import React from 'react';
import { Home, Dumbbell, BarChart2, User, Users } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'home', icon: <Home size={20} />, label: 'OS' },
    { id: 'workout', icon: <Dumbbell size={20} />, label: 'Train' },
    { id: 'social', icon: <Users size={20} />, label: 'Social' },
    { id: 'stats', icon: <BarChart2 size={20} />, label: 'Data' },
    { id: 'profile', icon: <User size={20} />, label: 'ID' },
  ];

  return (
    <div className="fixed bottom-0 left-0 w-full bg-black/95 backdrop-blur-xl border-t border-dark-700 pb-safe pt-2 px-4 z-40">
      <div className="flex justify-between items-center max-w-lg mx-auto h-16">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex flex-col items-center justify-center gap-1 w-12 transition-all duration-300 relative group
              ${activeTab === tab.id ? 'text-neon-400 -translate-y-1' : 'text-gray-500 hover:text-white'}`}
          >
            {activeTab === tab.id && (
              <div className="absolute -top-3 w-8 h-1 bg-neon-400 rounded-full shadow-[0_0_15px_#FF5500]"></div>
            )}
            <div className={`p-2 rounded-xl transition-all ${activeTab === tab.id ? 'bg-neon-400/10 scale-110' : ''}`}>
               {tab.icon}
            </div>
            <span className={`text-[9px] font-bold tracking-widest uppercase transition-opacity duration-300 ${activeTab === tab.id ? 'opacity-100' : 'opacity-0'}`}>
              {tab.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};