import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  icon?: React.ReactNode;
}

export const Input: React.FC<InputProps> = ({ label, icon, className = '', ...props }) => {
  return (
    <div className={`w-full ${className}`}>
      {label && <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">{label}</label>}
      <div className="relative group">
        <input 
          className="w-full bg-dark-800 border border-dark-700 text-white p-4 pl-4 focus:outline-none focus:border-neon-400 transition-colors placeholder-gray-600 rounded-sm"
          {...props}
        />
        {icon && (
          <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-neon-400 transition-colors">
            {icon}
          </div>
        )}
      </div>
    </div>
  );
};
