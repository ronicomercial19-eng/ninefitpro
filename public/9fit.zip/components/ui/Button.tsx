import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'ghost';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  className = '', 
  ...props 
}) => {
  const baseStyles = "py-4 px-6 rounded-none font-bold tracking-wider uppercase transition-all duration-300 flex items-center justify-center gap-2 text-sm";
  
  const variants = {
    primary: "bg-neon-400 text-black hover:bg-white hover:shadow-[0_0_20px_rgba(255,85,0,0.4)] border border-transparent",
    outline: "bg-transparent border border-white/20 text-white hover:border-neon-400 hover:text-neon-400",
    ghost: "bg-transparent text-white/60 hover:text-white"
  };

  const widthClass = fullWidth ? "w-full" : "";

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${widthClass} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};