import React from 'react';
import { X, Bell, Shield, Smartphone, LogOut } from 'lucide-react';

interface SettingsViewProps {
  onClose: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col animate-fade-in">
       <div className="flex items-center justify-between p-6 border-b border-dark-700">
         <h2 className="text-2xl font-black italic uppercase text-white tracking-tighter">System</h2>
         <button onClick={onClose} className="text-gray-500 hover:text-white">
            <X size={24} />
         </button>
       </div>

       <div className="p-6 space-y-6">
          <div className="space-y-4">
             <p className="text-gray-500 text-xs uppercase tracking-widest font-bold">Preferences</p>
             <div className="flex items-center justify-between p-4 bg-dark-800 border border-dark-700">
                <div className="flex items-center gap-3">
                   <Bell size={20} className="text-white" />
                   <span className="text-white font-bold uppercase text-sm">Notifications</span>
                </div>
                <div className="w-10 h-5 bg-neon-400 rounded-full relative cursor-pointer">
                   <div className="absolute right-1 top-1 w-3 h-3 bg-black rounded-full"></div>
                </div>
             </div>
             <div className="flex items-center justify-between p-4 bg-dark-800 border border-dark-700">
                <div className="flex items-center gap-3">
                   <Smartphone size={20} className="text-white" />
                   <span className="text-white font-bold uppercase text-sm">Haptic Feedback</span>
                </div>
                <div className="w-10 h-5 bg-dark-600 rounded-full relative cursor-pointer">
                   <div className="absolute left-1 top-1 w-3 h-3 bg-white rounded-full"></div>
                </div>
             </div>
          </div>

          <div className="space-y-4">
             <p className="text-gray-500 text-xs uppercase tracking-widest font-bold">Account</p>
             <button className="w-full flex items-center justify-between p-4 bg-dark-800 border border-dark-700 text-left hover:border-white/20 transition-colors">
                <div className="flex items-center gap-3">
                   <Shield size={20} className="text-white" />
                   <span className="text-white font-bold uppercase text-sm">Privacy & Data</span>
                </div>
             </button>
             <button className="w-full flex items-center justify-between p-4 bg-red-900/10 border border-red-900/30 text-left hover:bg-red-900/20 transition-colors text-red-500">
                <div className="flex items-center gap-3">
                   <LogOut size={20} />
                   <span className="font-bold uppercase text-sm">Terminate Session</span>
                </div>
             </button>
          </div>
       </div>
    </div>
  );
};
