import React from 'react';
import { X, Check, Crown } from 'lucide-react';
import { Button } from '../ui/Button';

interface PremiumViewProps {
  onClose: () => void;
}

export const PremiumView: React.FC<PremiumViewProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col animate-fade-in">
       <button onClick={onClose} className="absolute top-6 right-6 text-gray-500 hover:text-white z-20">
          <X size={24} />
       </button>

       <div className="flex-1 overflow-y-auto pb-safe">
          {/* Header */}
          <div className="pt-24 pb-12 px-6 text-center relative overflow-hidden">
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-yellow-600/20 blur-[100px] rounded-full"></div>
             <Crown size={64} className="text-yellow-500 mx-auto mb-6 relative z-10" />
             <h2 className="text-5xl font-black italic text-white uppercase tracking-tighter relative z-10 mb-2">
               9FIT <span className="text-yellow-500">Gold</span>
             </h2>
             <p className="text-gray-400 uppercase tracking-widest text-sm relative z-10">Unlock Your Genetic Potential</p>
          </div>

          {/* Comparison */}
          <div className="px-6 space-y-4 max-w-md mx-auto">
             {[
               { feat: 'Advanced Metrics', free: true, pro: true },
               { feat: 'Fit360 AI Unlimited', free: false, pro: true },
               { feat: '9FLIX Programs', free: false, pro: true },
               { feat: 'Postura Pro Analysis', free: false, pro: true },
               { feat: 'Gold Badge', free: false, pro: true },
             ].map((item, i) => (
                <div key={i} className="flex items-center justify-between py-3 border-b border-white/10">
                   <span className="text-sm font-bold text-gray-300 uppercase">{item.feat}</span>
                   <div className="flex items-center gap-8">
                      <span className="text-gray-600 w-6 flex justify-center">{item.free ? <Check size={16} /> : '-'}</span>
                      <span className="text-yellow-500 w-6 flex justify-center">{item.pro ? <Check size={16} /> : '-'}</span>
                   </div>
                </div>
             ))}
          </div>

          {/* Pricing */}
          <div className="p-6 mt-8">
             <div className="bg-gradient-to-br from-yellow-600/20 to-black border border-yellow-600/50 p-6 rounded-xl text-center">
                <p className="text-yellow-500 uppercase tracking-widest text-xs font-bold mb-2">Annual Access</p>
                <p className="text-4xl font-black text-white italic mb-1">$99<span className="text-lg text-gray-400">/yr</span></p>
                <p className="text-gray-500 text-xs mb-6">Less than $9/month</p>
                <Button fullWidth className="bg-yellow-500 hover:bg-yellow-400 text-black border-none">
                   Upgrade Now
                </Button>
             </div>
          </div>
       </div>
    </div>
  );
};
