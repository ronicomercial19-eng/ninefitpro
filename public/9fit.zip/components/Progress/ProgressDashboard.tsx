import React from 'react';
import { TrendingUp, Activity, Scale } from 'lucide-react';

export const ProgressDashboard: React.FC = () => {
  // Mock Data Points for Chart
  const weightData = [82, 81.5, 81.2, 80.8, 80.5, 80.1, 79.8];
  const maxWeight = Math.max(...weightData) + 1;
  const minWeight = Math.min(...weightData) - 1;
  const range = maxWeight - minWeight;

  const getPoints = () => {
     return weightData.map((val, idx) => {
        const x = (idx / (weightData.length - 1)) * 100;
        const y = 100 - ((val - minWeight) / range) * 100;
        return `${x},${y}`;
     }).join(' ');
  };

  return (
    <div className="space-y-6 pb-24">
      {/* HUD Header */}
      <div className="flex justify-between items-center">
         <h2 className="text-2xl font-black italic uppercase tracking-tighter text-white">
           Biometrics
         </h2>
         <div className="flex items-center gap-2 text-neon-400">
            <Activity size={16} className="animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-widest">Live</span>
         </div>
      </div>

      {/* Main Graph Card */}
      <div className="bg-dark-900 border border-dark-700 p-6 relative overflow-hidden">
         {/* Grid Background */}
         <div className="absolute inset-0" style={{ 
            backgroundImage: 'linear-gradient(#1E1E1E 1px, transparent 1px), linear-gradient(90deg, #1E1E1E 1px, transparent 1px)', 
            backgroundSize: '20px 20px',
            opacity: 0.2
         }}></div>

         <div className="relative z-10 mb-4 flex justify-between items-end">
             <div>
                <p className="text-gray-500 text-xs uppercase tracking-widest flex items-center gap-2">
                   <Scale size={12} /> Body Weight
                </p>
                <h3 className="text-4xl font-black text-white italic">79.8 <span className="text-sm font-normal not-italic text-gray-500">KG</span></h3>
             </div>
             <span className="text-neon-400 text-xs font-bold bg-neon-400/10 px-2 py-1 rounded-sm">-2.2%</span>
         </div>

         {/* SVG Line Chart */}
         <div className="h-40 w-full relative">
            <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible" preserveAspectRatio="none">
               {/* Line */}
               <polyline 
                  points={getPoints()} 
                  fill="none" 
                  stroke="#FF5500" 
                  strokeWidth="2" 
                  vectorEffect="non-scaling-stroke"
               />
               {/* Area */}
               <polygon 
                  points={`0,100 ${getPoints()} 100,100`} 
                  fill="url(#gradient)" 
                  opacity="0.2"
               />
               <defs>
                  <linearGradient id="gradient" x1="0" x2="0" y1="0" y2="1">
                     <stop offset="0%" stopColor="#FF5500" />
                     <stop offset="100%" stopColor="transparent" />
                  </linearGradient>
               </defs>
               
               {/* Data Points */}
               {weightData.map((val, idx) => {
                   const x = (idx / (weightData.length - 1)) * 100;
                   const y = 100 - ((val - minWeight) / range) * 100;
                   return (
                      <circle key={idx} cx={x} cy={y} r="1.5" fill="#000" stroke="#FF5500" strokeWidth="0.5" />
                   );
               })}
            </svg>
         </div>
         <div className="flex justify-between text-[10px] text-gray-600 uppercase mt-2 font-bold tracking-wider">
             <span>Mon</span>
             <span>Tue</span>
             <span>Wed</span>
             <span>Thu</span>
             <span>Fri</span>
             <span>Sat</span>
             <span>Sun</span>
         </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
          {[
            { label: 'Body Fat', value: '14.2%', change: '-0.4%', icon: <Activity size={16} /> },
            { label: 'Muscle Mass', value: '62.5kg', change: '+0.2%', icon: <TrendingUp size={16} /> },
            { label: 'VO2 Max', value: '52', change: '+1', icon: <ZapIcon /> },
            { label: 'BMI', value: '23.4', change: '0.0', icon: <Scale size={16} /> },
          ].map((stat, i) => (
             <div key={i} className="bg-dark-800 border border-dark-700 p-4 flex flex-col justify-between hover:border-white/20 transition-colors group">
                <div className="flex justify-between items-start mb-2">
                   <span className="text-gray-500 group-hover:text-neon-400 transition-colors">{stat.icon}</span>
                   <span className={`text-[10px] font-bold ${stat.change.startsWith('+') ? 'text-neon-400' : stat.change.startsWith('-') ? 'text-blue-400' : 'text-gray-500'}`}>
                      {stat.change}
                   </span>
                </div>
                <div>
                   <h4 className="text-2xl font-bold text-white">{stat.value}</h4>
                   <p className="text-[10px] text-gray-500 uppercase tracking-widest">{stat.label}</p>
                </div>
             </div>
          ))}
      </div>
    </div>
  );
};

const ZapIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></svg>
);