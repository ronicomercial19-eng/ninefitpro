import React from 'react';
import { Flame, Bot, ShoppingBag, Settings, Crown, Play, Dumbbell, BarChart2 } from 'lucide-react';
import { UserProfile, DailyStats } from '../../types';
import { MissionCard } from '../Dashboard/MissionCard';

interface HubViewProps {
  userProfile: UserProfile;
  onLaunchApp: (appId: string) => void;
}

export const HubView: React.FC<HubViewProps> = ({ userProfile, onLaunchApp }) => {
  // Simulated stats
  const stats: DailyStats = {
    xp: 1250,
    level: 4,
    streak: 12,
    caloriesBurned: 0,
    workoutsCompleted: 0
  };

  const levelProgress = (stats.xp % 1000) / 10;

  const APPS = [
    { id: 'fit360', name: 'Fit360', icon: <Bot size={24} />, color: 'text-neon-400', bg: 'bg-neon-400/10' },
    { id: 'smart_treino', name: 'SmartTreino', icon: <Dumbbell size={24} />, color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { id: '9flix', name: '9FLIX', icon: <Play size={24} />, color: 'text-red-500', bg: 'bg-red-500/10' },
    { id: '9progress', name: '9Progress', icon: <BarChart2 size={24} />, color: 'text-purple-400', bg: 'bg-purple-400/10' },
    { id: 'store', name: 'Store', icon: <ShoppingBag size={24} />, color: 'text-white', bg: 'bg-gray-800' },
    { id: 'premium', name: 'Premium', icon: <Crown size={24} />, color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
  ];

  return (
    <div className="space-y-6 pb-24">
      {/* Top Bar / HUD */}
      <div className="flex items-center justify-between bg-black/80 backdrop-blur-md sticky top-0 z-30 py-4 border-b border-white/5 -mx-6 px-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-dark-800 rounded-full border border-dark-700 flex items-center justify-center text-xs font-black text-white relative">
            LVL {stats.level}
            <div className="absolute inset-0 rounded-full border-2 border-neon-400/30"></div>
          </div>
          <div className="flex flex-col">
             <span className="text-[10px] text-gray-500 uppercase tracking-widest">XP Progress</span>
             <div className="w-24 h-1.5 bg-dark-800 rounded-full overflow-hidden mt-1">
                <div 
                  className="h-full bg-neon-400 transition-all duration-1000 ease-out" 
                  style={{ width: `${levelProgress}%` }}
                ></div>
             </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
           <div className="flex items-center gap-2 px-3 py-1.5 bg-dark-800 rounded-full border border-dark-700">
             <Flame size={14} className="text-orange-500 fill-orange-500 animate-pulse" />
             <span className="text-xs font-bold text-white">{stats.streak}</span>
           </div>
           <button onClick={() => onLaunchApp('settings')} className="text-gray-500 hover:text-white">
              <Settings size={20} />
           </button>
        </div>
      </div>
        
      {/* Date Header */}
      <div>
        <h1 className="text-3xl font-black italic tracking-tighter uppercase text-white">
          9FIT OS
        </h1>
        <p className="text-neon-400 text-xs uppercase tracking-[0.2em] font-bold">
          System Operational
        </p>
      </div>

      {/* Focus Module */}
      <MissionCard 
        goal={userProfile.goal || 'General Fitness'} 
        onComplete={() => {}} 
      />

      {/* App Grid */}
      <div>
         <h3 className="text-white font-bold uppercase tracking-wider text-sm mb-4">Ecosystem</h3>
         <div className="grid grid-cols-3 gap-3">
            {APPS.map((app) => (
               <button 
                  key={app.id}
                  onClick={() => onLaunchApp(app.id)}
                  className="bg-dark-800 border border-dark-700 rounded-xl aspect-square flex flex-col items-center justify-center gap-3 hover:bg-dark-700 hover:border-white/20 transition-all group active:scale-95"
               >
                  <div className={`w-12 h-12 rounded-full ${app.bg} flex items-center justify-center ${app.color} group-hover:scale-110 transition-transform`}>
                     {app.icon}
                  </div>
                  <span className="text-[10px] font-bold uppercase text-gray-400 group-hover:text-white">{app.name}</span>
               </button>
            ))}
         </div>
      </div>
    </div>
  );
};
