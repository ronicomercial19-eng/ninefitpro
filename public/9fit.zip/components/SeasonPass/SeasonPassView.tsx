import React from 'react';
import { Crown, Lock, Gift } from 'lucide-react';
import { SeasonTier } from '../../types';

const TIERS: SeasonTier[] = Array.from({ length: 15 }, (_, i) => ({
  tier: i + 1,
  reward: i % 5 === 0 ? 'Premium Skin' : '100 Credits',
  status: i < 3 ? 'CLAIMED' : i === 3 ? 'UNLOCKED' : 'LOCKED',
  isPremium: i % 2 !== 0
}));

export const SeasonPassView: React.FC = () => {
  return (
    <div className="space-y-6 pb-24">
       {/* Season Header */}
       <div className="bg-gradient-to-r from-yellow-600/20 to-transparent border border-yellow-600/30 p-6 relative overflow-hidden">
          <div className="flex justify-between items-end relative z-10">
             <div>
               <span className="text-yellow-500 font-bold text-xs uppercase tracking-widest flex items-center gap-2 mb-1">
                 <Crown size={14} /> Season 1
               </span>
               <h2 className="text-3xl font-black italic text-white uppercase tracking-tighter">
                 Genesis
               </h2>
             </div>
             <div className="text-right">
               <p className="text-xs text-gray-400 uppercase tracking-widest">Ends in</p>
               <p className="text-xl font-bold text-white font-mono">24D 12H</p>
             </div>
          </div>
       </div>

       {/* Horizontal Scroll Track */}
       <div className="relative w-full overflow-x-auto pb-8 hide-scrollbar">
          <div className="flex items-center px-6 gap-0 min-w-max">
             {TIERS.map((tier, index) => (
                <div key={tier.tier} className="relative flex flex-col items-center">
                   
                   {/* Connection Line */}
                   {index < TIERS.length - 1 && (
                      <div className={`absolute top-[45%] left-[50%] w-full h-1 z-0
                        ${tier.status === 'CLAIMED' ? 'bg-neon-400' : 'bg-dark-700'}`} 
                      />
                   )}

                   {/* Node Card */}
                   <div className={`w-32 h-40 flex flex-col items-center justify-center border-2 mx-2 relative z-10 transition-all group
                      ${tier.status === 'UNLOCKED' 
                         ? 'bg-dark-800 border-neon-400 shadow-[0_0_20px_rgba(204,255,0,0.2)] scale-110' 
                         : tier.status === 'CLAIMED'
                           ? 'bg-dark-900 border-neon-400/50 opacity-80'
                           : 'bg-black border-dark-700 opacity-60 grayscale'
                      }
                   `}>
                      {tier.isPremium && (
                        <div className="absolute top-2 right-2 text-yellow-500">
                           <Crown size={12} fill="currentColor" />
                        </div>
                      )}
                      
                      <div className={`p-3 rounded-full mb-3 
                        ${tier.status === 'UNLOCKED' ? 'bg-neon-400 text-black animate-pulse' : 'bg-dark-700 text-gray-500'}`}>
                         {tier.status === 'LOCKED' ? <Lock size={20} /> : <Gift size={20} />}
                      </div>
                      
                      <span className="text-xs font-bold uppercase text-white mb-1">Tier {tier.tier}</span>
                      <span className="text-[10px] text-gray-400 uppercase text-center px-2">{tier.reward}</span>

                      {/* Status Indicator */}
                      {tier.status === 'UNLOCKED' && (
                         <button className="absolute -bottom-3 bg-neon-400 text-black text-[10px] font-black uppercase px-3 py-1 tracking-wider shadow-lg hover:scale-105 transition-transform">
                            Claim
                         </button>
                      )}
                   </div>
                </div>
             ))}
          </div>
       </div>

       {/* Profile Summary */}
       <div className="px-6">
          <h3 className="text-white font-bold uppercase tracking-wider mb-4 border-b border-white/10 pb-2">Identity</h3>
          <div className="bg-dark-800 border border-dark-700 p-4 flex items-center gap-4">
             <div className="w-16 h-16 bg-gradient-to-br from-gray-700 to-black rounded-full border border-gray-600 flex items-center justify-center">
                <span className="text-2xl">💀</span>
             </div>
             <div>
                <h4 className="text-white font-bold uppercase">Operative #992</h4>
                <p className="text-xs text-neon-400 uppercase tracking-widest">Premium Member</p>
             </div>
          </div>
       </div>
    </div>
  );
};
