import React, { useState, useEffect } from 'react';
import { ArrowRight, Check, Dumbbell, Zap, Heart, Target, Sparkles, Search } from 'lucide-react';
import { Button } from '../ui/Button';
import { UserProfile, AIInsight } from '../../types';
import { generateGoalInsight } from '../../services/geminiService';

interface OnboardingFlowProps {
  onComplete: (profile: UserProfile) => void;
}

const TOTAL_STEPS = 5;

export const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<UserProfile>({});
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [insight, setInsight] = useState<AIInsight | null>(null);

  const handleNext = () => {
    if (step < TOTAL_STEPS) {
      setStep(prev => prev + 1);
    } else {
      onComplete(profile);
    }
  };

  const updateProfile = (key: keyof UserProfile, value: any) => {
    setProfile(prev => ({ ...prev, [key]: value }));
  };

  // Step 5: Trigger AI Analysis when entering step 5
  useEffect(() => {
    if (step === 5 && profile.goal) {
      const fetchInsight = async () => {
        setIsAnalyzing(true);
        const result = await generateGoalInsight(profile.goal!);
        setInsight(result);
        setIsAnalyzing(false);
      };
      fetchInsight();
    }
  }, [step, profile.goal]);

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-8 animate-slide-up">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold uppercase tracking-wide">Primary Objective</h2>
              <p className="text-gray-400">What is your main goal?</p>
            </div>
            <div className="grid gap-4">
              {[
                { id: 'lose_weight', label: 'Lose Weight', icon: <Heart className="text-neon-400" /> },
                { id: 'gain_muscle', label: 'Gain Muscle', icon: <Dumbbell className="text-neon-400" /> },
                { id: 'endurance', label: 'Endurance', icon: <Zap className="text-neon-400" /> },
                { id: 'flexibility', label: 'Flexibility', icon: <ActivityIcon /> }
              ].map((option) => (
                <button
                  key={option.id}
                  onClick={() => {
                    updateProfile('goal', option.label);
                    handleNext();
                  }}
                  className="group flex items-center p-6 bg-dark-800 border border-dark-700 hover:border-neon-400 hover:bg-dark-700 transition-all text-left"
                >
                  <div className="bg-black p-3 rounded-full mr-4 group-hover:scale-110 transition-transform">
                    {option.icon}
                  </div>
                  <span className="text-lg font-medium tracking-wide">{option.label}</span>
                  <ArrowRight className="ml-auto opacity-0 group-hover:opacity-100 text-neon-400 transition-opacity" />
                </button>
              ))}
            </div>
          </div>
        );
      
      case 2:
        return (
          <div className="space-y-8 animate-slide-up">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold uppercase tracking-wide">Experience Level</h2>
              <p className="text-gray-400">Define your current baseline.</p>
            </div>
            <div className="grid grid-cols-1 gap-4">
              {['Beginner', 'Intermediate', 'Advanced', 'Athlete'].map((level) => (
                <button
                  key={level}
                  onClick={() => {
                    updateProfile('experienceLevel', level);
                    handleNext();
                  }}
                  className={`p-6 border transition-all text-center uppercase tracking-widest font-bold 
                    ${profile.experienceLevel === level 
                      ? 'bg-neon-400 text-black border-neon-400' 
                      : 'bg-transparent border-dark-700 text-gray-500 hover:border-white hover:text-white'}`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-8 animate-slide-up">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold uppercase tracking-wide">Commitment</h2>
              <p className="text-gray-400">Days per week available for training.</p>
            </div>
            <div className="flex justify-between gap-2">
              {[2, 3, 4, 5, 6].map((days) => (
                <button
                  key={days}
                  onClick={() => {
                    updateProfile('availability', days);
                    handleNext();
                  }}
                  className={`w-14 h-14 md:w-16 md:h-16 flex items-center justify-center border transition-all font-bold text-xl
                    ${profile.availability === days 
                      ? 'bg-neon-400 text-black border-neon-400 shadow-[0_0_15px_rgba(255,85,0,0.5)]' 
                      : 'bg-dark-800 border-dark-700 text-gray-400 hover:border-neon-400 hover:text-white'}`}
                >
                  {days}
                </button>
              ))}
            </div>
            <div className="text-center text-xs text-gray-500 uppercase tracking-widest">
              {profile.availability ? `${profile.availability} Days / Week Selected` : 'Select frequency'}
            </div>
          </div>
        );

      case 4: 
        return (
           <div className="space-y-8 animate-slide-up">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold uppercase tracking-wide">Metrics (Optional)</h2>
              <p className="text-gray-400">Calibrate your profile for precision.</p>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-gray-500">Estimated Weight (kg)</label>
                <input 
                  type="number" 
                  className="w-full bg-dark-800 border border-dark-700 p-4 text-white focus:border-neon-400 focus:outline-none"
                  placeholder="00.0"
                  onChange={(e) => updateProfile('measurements', { ...profile.measurements, weight: parseFloat(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-gray-500">Estimated Height (cm)</label>
                <input 
                  type="number" 
                  className="w-full bg-dark-800 border border-dark-700 p-4 text-white focus:border-neon-400 focus:outline-none"
                  placeholder="000"
                  onChange={(e) => updateProfile('measurements', { ...profile.measurements, height: parseFloat(e.target.value) })}
                />
              </div>
              <Button onClick={handleNext} fullWidth variant="outline" className="mt-4">
                Skip / Continue
              </Button>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-8 animate-slide-up text-center">
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="relative">
                <div className={`absolute inset-0 bg-neon-400 blur-xl opacity-20 rounded-full ${isAnalyzing ? 'animate-pulse' : ''}`}></div>
                <Sparkles size={48} className={`relative z-10 ${isAnalyzing ? 'text-neon-400 animate-spin-slow' : 'text-white'}`} />
              </div>
              
              <h2 className="text-2xl font-bold uppercase tracking-wide">
                {isAnalyzing ? 'AI Analysis In Progress...' : 'Plan Generated'}
              </h2>
            </div>

            {isAnalyzing ? (
              <div className="py-10 space-y-4">
                 <div className="h-1 w-full bg-dark-800 overflow-hidden">
                    <div className="h-full bg-neon-400 w-1/2 animate-[shimmer_1.5s_infinite]"></div>
                 </div>
                 <p className="text-gray-500 text-sm">Consulting global database for "{profile.goal}"...</p>
              </div>
            ) : (
              <div className="bg-dark-800/50 border border-dark-700 p-6 text-left space-y-4 relative overflow-hidden">
                {/* Decorative DNA strip */}
                <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-neon-400 to-transparent"></div>
                
                <h3 className="text-neon-400 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                  <Target size={14} /> 9FIT Intelligence
                </h3>
                
                <p className="text-lg leading-relaxed text-gray-200">
                  {insight?.text}
                </p>

                {insight?.sources && insight.sources.length > 0 && (
                  <div className="pt-4 border-t border-white/5">
                    <p className="text-[10px] uppercase text-gray-500 mb-2 flex items-center gap-1">
                      <Search size={10} /> Verified Source
                    </p>
                    {insight.sources.map((source, idx) => (
                      <a 
                        key={idx} 
                        href={source.web?.uri} 
                        target="_blank" 
                        rel="noreferrer"
                        className="block text-xs text-neon-400 truncate hover:underline"
                      >
                        {source.web?.title}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}

            {!isAnalyzing && (
              <Button onClick={handleNext} fullWidth className="animate-pulse">
                Enter Dashboard
              </Button>
            )}
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col p-6">
      {/* Header Progress */}
      <div className="w-full flex justify-between items-center mb-12 pt-4">
         <span className="text-neon-400 font-bold italic tracking-tighter text-xl">9FIT</span>
         <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map(s => (
              <div 
                key={s} 
                className={`w-2 h-2 rounded-full transition-colors duration-500 ${s <= step ? 'bg-neon-400' : 'bg-dark-800'}`}
              />
            ))}
         </div>
      </div>

      {/* Dynamic Content */}
      <div className="flex-1 max-w-md w-full mx-auto flex flex-col justify-center pb-10">
        {renderStep()}
      </div>
    </div>
  );
};

// Helper Icon
const ActivityIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neon-400"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
);