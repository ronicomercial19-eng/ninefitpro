import React, { useState } from 'react';
import { X, Zap, Brain, Check } from 'lucide-react';
import { Button } from '../ui/Button';

interface DailyCheckInProps {
  onClose: () => void;
  onComplete: () => void;
}

export const DailyCheckIn: React.FC<DailyCheckInProps> = ({ onClose, onComplete }) => {
  const [energy, setEnergy] = useState(5);
  const [stress, setStress] = useState(5);

  const getEmoji = (val: number) => {
    if (val <= 3) return '😫';
    if (val <= 7) return '😐';
    return '⚡️';
  };

  const handleSubmit = () => {
    onComplete();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-dark-800 border-t md:border border-dark-700 p-6 rounded-t-3xl md:rounded-3xl shadow-2xl relative animate-slide-up">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-white"
        >
          <X size={20} />
        </button>

        <h2 className="text-xl font-bold uppercase tracking-wide mb-1 text-white">Daily Check-in</h2>
        <p className="text-xs text-gray-500 mb-8 uppercase tracking-widest">Calibrate System Variables</p>

        <div className="space-y-8 mb-8">
          {/* Energy Slider */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-bold flex items-center gap-2 text-neon-400">
                <Zap size={16} /> ENERGY
              </label>
              <span className="text-2xl">{getEmoji(energy)}</span>
            </div>
            <input 
              type="range" 
              min="1" 
              max="10" 
              value={energy} 
              onChange={(e) => setEnergy(parseInt(e.target.value))}
              className="w-full h-2 bg-dark-900 rounded-lg appearance-none cursor-pointer accent-neon-400"
            />
            <div className="flex justify-between text-[10px] text-gray-600 uppercase font-bold">
              <span>Low Battery</span>
              <span>Overcharged</span>
            </div>
          </div>

          {/* Stress Slider */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-bold flex items-center gap-2 text-blue-400">
                <Brain size={16} /> STRESS
              </label>
              <span className="text-2xl">{stress > 7 ? '🤯' : stress > 3 ? '😌' : '🧘'}</span>
            </div>
            <input 
              type="range" 
              min="1" 
              max="10" 
              value={stress} 
              onChange={(e) => setStress(parseInt(e.target.value))}
              className="w-full h-2 bg-dark-900 rounded-lg appearance-none cursor-pointer accent-blue-400"
            />
            <div className="flex justify-between text-[10px] text-gray-600 uppercase font-bold">
              <span>Zen</span>
              <span>Critical</span>
            </div>
          </div>
        </div>

        <Button fullWidth onClick={handleSubmit}>
          Log Metrics <Check size={18} />
        </Button>
      </div>
    </div>
  );
};
