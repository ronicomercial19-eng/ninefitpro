import React, { useState } from 'react';
import { UserProfile } from '../../types';
import { BottomNav } from '../ui/BottomNav';
import { HubView } from '../Hub/HubView';
import { TrainView } from '../Train/TrainView';
import { SocialView } from '../Social/SocialView';
import { ProfileView } from '../Profile/ProfileView';
import { ProgressDashboard } from '../Progress/ProgressDashboard';

// Apps
import { Fit360 } from '../Apps/Fit360';
import { NineFlix } from '../Apps/NineFlix';
import { StoreView } from '../Shop/StoreView';
import { PremiumView } from '../Premium/PremiumView';
import { SettingsView } from '../Settings/SettingsView';

interface DashboardProps {
  userProfile: UserProfile;
}

export const Dashboard: React.FC<DashboardProps> = ({ userProfile }) => {
  const [activeTab, setActiveTab] = useState('home');
  const [activeApp, setActiveApp] = useState<string | null>(null);

  const handleLaunchApp = (appId: string) => {
    if (appId === 'smart_treino') {
       setActiveTab('workout');
    } else if (appId === '9progress') {
       setActiveTab('stats');
    } else {
       setActiveApp(appId);
    }
  };

  const closeApp = () => setActiveApp(null);

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <HubView userProfile={userProfile} onLaunchApp={handleLaunchApp} />;
      case 'workout':
        return <TrainView />;
      case 'social':
        return <SocialView />;
      case 'stats':
        return <ProgressDashboard />;
      case 'profile':
        return <ProfileView />;
      default:
        return <HubView userProfile={userProfile} onLaunchApp={handleLaunchApp} />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white relative">
      <main className="p-6 animate-fade-in min-h-screen">
        {renderContent()}
      </main>
      
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* App Overlays */}
      {activeApp === 'fit360' && <Fit360 onClose={closeApp} />}
      {activeApp === '9flix' && <NineFlix onClose={closeApp} />}
      {activeApp === 'store' && <StoreView coins={1250} onClose={closeApp} />}
      {activeApp === 'premium' && <PremiumView onClose={closeApp} />}
      {activeApp === 'settings' && <SettingsView onClose={closeApp} />}
    </div>
  );
};
