import React, { useEffect, useState } from 'react';
import { Flag, Loader, CheckCircle } from 'lucide-react';
import { generateDailyMission } from '../../services/geminiService';
import { DailyMission } from '../../types';

interface MissionCardProps {
  goal: string;
  onComplete: (xp: number) => void;
}

export const MissionCard: React.FC<MissionCardProps> = ({ goal, onComplete }) => {
  const [mission, setMission] = useState<DailyMission | null>(null);
  const [loading, setLoading] = useState(true);
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    const fetchMission = async () => {
      const data = await generateDailyMission(goal);
      setMission(data);
      setLoading(false);
    };
    fetchMission();
  }, [goal]);

  if (loading) {
    return (
      <div className="bg-dark-800 border border-dark-700 p-6 rounded-sm min-h-[160px] flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-[shimmer_2s_infinite]"></div>
        <p className="text-xs text-gray-500 uppercase tracking-widest animate-pulse">Decrypting Mission...</p>
      </div>
    );
  }

  if (!mission) return null;

  return (
    <div className={`relative p-6 border transition-all duration-500 overflow-hidden group
      ${completed ? 'bg-neon-400/10 border-neon-400' : 'bg-gradient-to-br from-dark-800 to-black border-dark-700 hover:border-white/20'}`}>
      
      {/* Background Visuals */}
      <div className="absolute right-0 top-0 w-64 h-64 bg-neon-400/5 blur-[80px] rounded-full pointer-events-none"></div>
      
      <div className="relative z-10">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-2">
            <span className="bg-neon-400 text-black text-[10px] font-black px-2 py-0.5 uppercase tracking-widest rounded-sm">
              Daily Mission
            </span>
            <span className="text-gray-500 text-[10px] uppercase tracking-wider">
              {mission.type}
            </span>
          </div>
          <div className="flex items-center gap-1 text-neon-400 text-xs font-bold">
            +{mission.xpReward} XP
          </div>
        </div>

        <h3 className="text-2xl font-black italic tracking-tighter text-white mb-2 leading-none uppercase">
          {mission.title}
        </h3>
        
        <p className="text-sm text-gray-400 mb-6 leading-relaxed max-w-[90%]">
          {mission.description}
        </p>

        {completed ? (
          <div className="flex items-center gap-2 text-neon-400 font-bold uppercase tracking-widest text-sm">
            <CheckCircle size={18} /> Mission Accomplished
          </div>
        ) : (
          <button 
            onClick={() => {
              setCompleted(true);
              onComplete(mission.xpReward);
            }}
            className="flex items-center gap-3 text-white border-b border-white pb-1 hover:text-neon-400 hover:border-neon-400 transition-colors uppercase tracking-widest text-xs font-bold"
          >
            Mark Complete <Flag size={12} />
          </button>
        )}
      </div>
    </div>
  );
};
