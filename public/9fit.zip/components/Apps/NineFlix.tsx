import React from 'react';
import { X, Play, Info } from 'lucide-react';

interface NineFlixProps {
  onClose: () => void;
}

export const NineFlix: React.FC<NineFlixProps> = ({ onClose }) => {
  const categories = [
    { title: "Featured Programs", items: ["bg-red-900", "bg-orange-900", "bg-yellow-900"] },
    { title: "Technique Mastery", items: ["bg-blue-900", "bg-indigo-900", "bg-violet-900", "bg-purple-900"] },
    { title: "Mindset & Flow", items: ["bg-emerald-900", "bg-teal-900", "bg-cyan-900"] },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black overflow-y-auto animate-fade-in">
      {/* Navbar */}
      <div className="fixed top-0 w-full z-50 bg-gradient-to-b from-black to-transparent p-6 flex justify-between items-center">
        <h2 className="text-3xl font-black italic tracking-tighter text-red-600">9FLIX</h2>
        <button onClick={onClose} className="text-white hover:text-red-600 transition-colors">
          <X size={24} />
        </button>
      </div>

      {/* Hero */}
      <div className="relative h-[70vh] w-full">
         <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1599058945522-28d584b6f0ff?q=80&w=1469&auto=format&fit=crop')] bg-cover bg-center"></div>
         <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
         <div className="absolute bottom-0 left-0 p-6 w-full max-w-2xl pb-12">
            <span className="text-red-600 font-bold uppercase tracking-widest text-xs mb-2 block">New Season</span>
            <h1 className="text-5xl font-black italic text-white mb-4 uppercase leading-none">Unleashed<br/>Potency</h1>
            <p className="text-gray-300 text-sm mb-6 line-clamp-2">Master the art of explosive power with our new 4-week program designed for tactical athletes.</p>
            <div className="flex gap-4">
               <button className="flex items-center gap-2 bg-white text-black px-6 py-3 rounded-sm font-bold uppercase tracking-wider hover:bg-gray-200">
                  <Play size={18} fill="currentColor" /> Play
               </button>
               <button className="flex items-center gap-2 bg-gray-600/50 backdrop-blur-sm text-white px-6 py-3 rounded-sm font-bold uppercase tracking-wider hover:bg-gray-600/70">
                  <Info size={18} /> More Info
               </button>
            </div>
         </div>
      </div>

      {/* Rows */}
      <div className="relative z-10 -mt-8 pb-24 space-y-8 pl-6">
         {categories.map((cat, i) => (
            <div key={i}>
               <h3 className="text-white font-bold uppercase tracking-wider text-sm mb-3">{cat.title}</h3>
               <div className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar pr-6">
                  {cat.items.map((color, idx) => (
                     <div key={idx} className={`w-40 h-60 flex-shrink-0 ${color} rounded-sm border border-white/10 hover:border-white hover:scale-105 transition-all cursor-pointer relative group`}>
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                           <Play size={32} className="text-white fill-white" />
                        </div>
                     </div>
                  ))}
               </div>
            </div>
         ))}
      </div>
    </div>
  );
};
