import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, X, Bot } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from '../../types';

interface Fit360Props {
  onClose: () => void;
}

export const Fit360: React.FC<Fit360Props> = ({ onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: '1', role: 'model', text: 'I am Fit360, your tactical performance AI. How can I optimize your routine today?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const apiKey = process.env.API_KEY || '';
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: input,
        config: {
          systemInstruction: "You are Fit360, a highly advanced, elite tactical fitness AI coach for the 9FIT app. Keep answers concise, professional, and motivating. Focus on science-based performance advice.",
        }
      });

      const text = response.text || "Systems calibrating. Please try again.";
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'model', text }]);
    } catch (error) {
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'model', text: "Connection to neural core interrupted. Check API key." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-dark-700 bg-dark-900">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-neon-400/10 rounded-full flex items-center justify-center text-neon-400 border border-neon-400">
            <Bot size={20} />
          </div>
          <div>
            <h2 className="text-white font-bold uppercase tracking-wider">Fit360 Copilot</h2>
            <p className="text-[10px] text-gray-500 uppercase tracking-widest flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span> Online
            </p>
          </div>
        </div>
        <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
          <X size={24} />
        </button>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed
              ${msg.role === 'user' 
                ? 'bg-dark-800 text-white rounded-tr-none border border-dark-700' 
                : 'bg-neon-400/10 text-gray-100 rounded-tl-none border border-neon-400/20'}`}>
              {msg.text}
            </div>
          </div>
        ))}
        {loading && (
           <div className="flex justify-start">
              <div className="bg-neon-400/5 text-neon-400 p-4 rounded-2xl rounded-tl-none border border-neon-400/10 flex items-center gap-2">
                 <Sparkles size={16} className="animate-spin-slow" /> Thinking...
              </div>
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-dark-700 bg-dark-900 pb-safe">
        <div className="flex items-center gap-2 bg-black border border-dark-700 rounded-full p-2 pr-2">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask Fit360..."
            className="flex-1 bg-transparent text-white px-4 py-2 focus:outline-none placeholder-gray-600 text-sm"
          />
          <button 
            onClick={handleSend}
            disabled={loading}
            className="w-10 h-10 bg-neon-400 rounded-full flex items-center justify-center text-black hover:bg-white transition-colors disabled:opacity-50"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};
