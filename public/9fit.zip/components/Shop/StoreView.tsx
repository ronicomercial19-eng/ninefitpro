import React from 'react';
import { X, ShoppingBag, Coins } from 'lucide-react';
import { StoreItem } from '../../types';

interface StoreViewProps {
  onClose: () => void;
  coins: number;
}

const ITEMS: StoreItem[] = [
  { id: '1', name: '9FIT Shaker Pro', price: 2500, image: 'bg-stone-800', category: 'GEAR' },
  { id: '2', name: 'Elite Whey', price: 5000, image: 'bg-stone-900', category: 'SUPPLEMENTS' },
  { id: '3', name: 'Hypertrophy 101', price: 1000, image: 'bg-blue-900', category: 'DIGITAL' },
  { id: '4', name: 'Black Tee', price: 3000, image: 'bg-neutral-800', category: 'GEAR' },
];

export const StoreView: React.FC<StoreViewProps> = ({ onClose, coins }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col animate-fade-in">
       {/* Header */}
       <div className="flex items-center justify-between p-6 border-b border-dark-700 bg-dark-900">
         <div>
            <h2 className="text-2xl font-black italic uppercase text-white tracking-tighter">Store</h2>
            <div className="flex items-center gap-1 text-yellow-500 font-bold text-sm">
               <Coins size={14} fill="currentColor" /> {coins} Credits
            </div>
         </div>
         <button onClick={onClose} className="text-gray-500 hover:text-white">
            <X size={24} />
         </button>
       </div>

       {/* Content */}
       <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-2 gap-4">
             {ITEMS.map((item) => (
                <div key={item.id} className="bg-dark-800 border border-dark-700 rounded-sm overflow-hidden group">
                   <div className={`h-32 ${item.image} relative flex items-center justify-center`}>
                      <ShoppingBag size={32} className="text-white/20 group-hover:text-neon-400 transition-colors" />
                   </div>
                   <div className="p-3">
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">{item.category}</p>
                      <h4 className="text-white font-bold uppercase text-sm mb-2">{item.name}</h4>
                      <button className="w-full py-2 bg-dark-700 text-white text-xs font-bold uppercase hover:bg-neon-400 hover:text-black transition-colors flex items-center justify-center gap-2">
                         {item.price} <Coins size={10} />
                      </button>
                   </div>
                </div>
             ))}
          </div>
       </div>
    </div>
  );
};
