import React, { useState } from 'react';
import { Lock, Check, Zap, Play, Trophy } from 'lucide-react';
import { Quest } from '../../types';
import { MissionCompleteOverlay } from './MissionCompleteOverlay';

const MOCK_QUESTS: Quest[] = [
  { id: '1', title: 'Morning Mobility', description: 'Complete 10 min stretch sequence', xp: 150, completed: false, type: 'DAILY' },
  { id: '2', title: 'Hydration Protocol', description: 'Log 3L of water intake', xp: 50, completed: true, type: 'DAILY' },
  { id: '3', title: 'High Intensity', description: 'Reach Zone 4 Heart Rate for 15 mins', xp: 300, completed: false, type: 'WEEKLY' },
  { id: '4', title: 'Mastery', description: 'Complete 5 perfect form squats', xp: 500, completed: false, type: 'SEASON', locked: true },
];

export const MissionList: React.FC = () => {
  const [quests, setQuests] = useState(MOCK_QUESTS);
  const [showOverlay, setShowOverlay] = useState<number | null>(null);

  const handleComplete = (id: string, xp: number) => {
    setQuests(prev => prev.map(q => q.id === id ? { ...q, completed: true } : q));
    setShowOverlay(xp);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between">
         <h2 className="text-2xl font-black italic uppercase tracking-tighter text-white">
           Active Operations
         </h2>
         <span className="text-xs font-bold bg-dark-800 border border-dark-700 px-3 py-1 text-neon-400 rounded-full">
           {quests.filter(q => q.completed).length}/{quests.length}
         </span>
      </div>

      {/* Fitness Test Module */}
      <div className="bg-gradient-to-r from-dark-800 to-black border border-l-4 border-dark-700 border-l-neon-400 p-6 relative overflow-hidden group">
         <div className="absolute right-0 top-0 w-32 h-32 bg-neon-400/5 blur-[50px]"></div>
         <div className="relative z-10">
            <h3 className="text-white font-bold uppercase tracking-wider mb-1">Baseline Assessment</h3>
            <p className="text-xs text-gray-500 mb-4 max-w-[70%]">Calibrate your physical metrics with the standard 9FIT protocol.</p>
            <button className="flex items-center gap-2 bg-white text-black px-4 py-2 font-bold text-xs uppercase tracking-widest hover:bg-neon-400 transition-colors">
               <Play size={12} fill="currentColor" /> Start Test
            </button>
         </div>
      </div>

      {/* Quest List */}
      <div className="space-y-3">
        {quests.map((quest) => (
          <div 
            key={quest.id} 
            className={`relative p-4 border transition-all ${
              quest.locked 
                ? 'bg-dark-900 border-dark-800 opacity-50' 
                : quest.completed 
                  ? 'bg-dark-800/50 border-neon-400/30' 
                  : 'bg-dark-800 border-dark-700 hover:border-white/20'
            }`}
          >
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded-sm ${
                    quest.type === 'DAILY' ? 'bg-blue-500/20 text-blue-400' :
                    quest.type === 'WEEKLY' ? 'bg-purple-500/20 text-purple-400' :
                    'bg-orange-500/20 text-orange-400'
                  }`}>
                    {quest.type}
                  </span>
                  {quest.locked && <Lock size={12} className="text-gray-600" />}
                </div>
                <h4 className={`font-bold uppercase tracking-wide text-sm ${quest.completed ? 'text-gray-500 line-through' : 'text-white'}`}>
                  {quest.title}
                </h4>
                <p className="text-xs text-gray-500 mt-1">{quest.description}</p>
              </div>

              <div className="flex flex-col items-end gap-2">
                <span className="text-neon-400 font-bold text-xs">+{quest.xp} XP</span>
                {!quest.locked && !quest.completed && (
                  <button 
                    onClick={() => handleComplete(quest.id, quest.xp)}
                    className="w-8 h-8 flex items-center justify-center bg-dark-700 hover:bg-neon-400 hover:text-black transition-colors rounded-sm text-gray-400"
                  >
                    <Check size={16} />
                  </button>
                )}
                {quest.completed && <Check size={16} className="text-neon-400" />}
              </div>
            </div>
            
            {/* Progress Bar (Visual only for now) */}
            {!quest.locked && !quest.completed && (
               <div className="w-full h-0.5 bg-dark-900 mt-3">
                  <div className="w-1/3 h-full bg-neon-400"></div>
               </div>
            )}
          </div>
        ))}
      </div>

      {showOverlay !== null && (
        <MissionCompleteOverlay xpGained={showOverlay} onClose={() => setShowOverlay(null)} />
      )}
    </div>
  );
};
