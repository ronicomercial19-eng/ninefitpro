import React, { useEffect } from 'react';
import { CheckCircle, Award } from 'lucide-react';
import { Button } from '../ui/Button';

interface MissionCompleteOverlayProps {
  xpGained: number;
  onClose: () => void;
}

export const MissionCompleteOverlay: React.FC<MissionCompleteOverlayProps> = ({ xpGained, onClose }) => {
  useEffect(() => {
    // Auto close after 3 seconds if not interacted
    const timer = setTimeout(onClose, 3500);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-xl animate-fade-in">
      {/* Background Burst */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-neon-400/20 blur-[100px] rounded-full animate-pulse"></div>
      </div>

      <div className="relative z-10 flex flex-col items-center text-center p-8 space-y-6 animate-slide-up">
        <div className="relative">
          <div className="absolute inset-0 bg-neon-400 blur-2xl opacity-50 rounded-full animate-ping"></div>
          <Award size={80} className="text-neon-400 relative z-10" />
        </div>

        <div>
          <h2 className="text-4xl font-black italic tracking-tighter text-white uppercase mb-2 drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
            Mission Complete
          </h2>
          <div className="w-full h-1 bg-neon-400/50 rounded-full mb-4"></div>
          <p className="text-2xl font-bold text-neon-400 tracking-[0.2em] animate-pulse">
            +{xpGained} XP
          </p>
        </div>

        <p className="text-gray-400 text-xs uppercase tracking-widest">
          Syncing neural interface...
        </p>

        <Button onClick={onClose} variant="outline" className="mt-8 border-neon-400 text-neon-400 hover:bg-neon-400 hover:text-black">
          Continue
        </Button>
      </div>
    </div>
  );
};
