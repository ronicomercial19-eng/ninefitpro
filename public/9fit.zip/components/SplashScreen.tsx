import React, { useEffect } from 'react';
import { Activity } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black">
      <div className="relative flex items-center justify-center animate-pulse-slow">
        {/* Glow effect */}
        <div className="absolute inset-0 bg-neon-400/20 blur-3xl rounded-full w-32 h-32 animate-pulse"></div>
        
        {/* Logo */}
        <div className="relative z-10 flex flex-col items-center animate-fade-in">
          <Activity size={64} className="text-neon-400 mb-4" />
          <h1 className="text-6xl font-black tracking-tighter text-white italic">
            9FIT
          </h1>
          <div className="w-full h-1 bg-gradient-to-r from-transparent via-neon-400 to-transparent mt-2"></div>
        </div>
      </div>
      
      <p className="absolute bottom-10 text-xs text-gray-600 tracking-[0.3em] uppercase animate-slide-up">
        System Initializing
      </p>
    </div>
  );
};
