import React, { useState } from 'react';
import { Mail, Lock, ArrowRight, Github, Chrome } from 'lucide-react';
import { Button } from './ui/Button';
import { Input } from './ui/Input';

interface LoginScreenProps {
  onLogin: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-black p-6 relative overflow-hidden animate-fade-in">
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-dark-800 rounded-full blur-[100px] opacity-40"></div>
        <div className="absolute top-[20%] right-[0%] w-[30%] h-[30%] bg-neon-400/5 rounded-full blur-[80px]"></div>
      </div>

      <div className="w-full max-w-md z-10 space-y-12">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold tracking-tight text-white">WELCOME BACK</h2>
          <p className="text-gray-500 text-sm tracking-wide">ENTER THE 9FIT ECOSYSTEM</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Input 
            type="email" 
            placeholder="ACCESS ID (EMAIL)" 
            icon={<Mail size={18} />}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Input 
            type="password" 
            placeholder="PASSPHRASE" 
            icon={<Lock size={18} />}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          
          <div className="flex justify-end">
             <button type="button" className="text-xs text-neon-400 hover:text-white transition-colors uppercase tracking-wider">Forgot access?</button>
          </div>

          <Button type="submit" fullWidth>
            Initiate Session <ArrowRight size={18} />
          </Button>
        </form>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-dark-700"></div>
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="bg-black px-2 text-gray-600 uppercase tracking-widest">Or connect via</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Button variant="outline" className="justify-center">
             <Chrome size={18} /> Google
          </Button>
          <Button variant="outline" className="justify-center">
             <Github size={18} /> Apple
          </Button>
        </div>
      </div>
    </div>
  );
};
