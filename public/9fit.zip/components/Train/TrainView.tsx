import React, { useState } from 'react';
import { Play, Users, Calendar } from 'lucide-react';
import { MissionList } from '../Missions/MissionList';
import { ClassPlayer } from './ClassPlayer';
import { ClassSession, Tribe } from '../../types';

const CLASSES: ClassSession[] = [
  { id: '1', title: 'HIIT Ignition', instructor: 'Coach Rex', duration: '30 min', intensity: 'High', image: 'bg-red-900' },
  { id: '2', title: 'Mobility Flow', instructor: 'Sarah J.', duration: '20 min', intensity: 'Low', image: 'bg-blue-900' },
  { id: '3', title: 'Strength Core', instructor: 'Mike T.', duration: '45 min', intensity: 'Medium', image: 'bg-orange-900' },
];

const TRIBES: Tribe[] = [
  { id: '1', name: 'Run Club', members: 1204, image: 'bg-slate-800' },
  { id: '2', name: 'CrossFit', members: 892, image: 'bg-stone-800' },
  { id: '3', name: 'Yoga', members: 540, image: 'bg-teal-900' },
];

export const TrainView: React.FC = () => {
  const [selectedClass, setSelectedClass] = useState<ClassSession | null>(null);

  return (
    <div className="space-y-8 pb-24">
      {/* Calendar Strip */}
      <div className="flex justify-between items-center">
         <h2 className="text-2xl font-black italic uppercase tracking-tighter text-white">Operations</h2>
         <Calendar className="text-gray-500" size={20} />
      </div>
      <div className="flex justify-between overflow-x-auto gap-3 pb-2 hide-scrollbar">
         {Array.from({length: 7}, (_, i) => i + new Date().getDate()).map((d, i) => (
            <div key={i} className={`flex flex-col items-center justify-center w-12 h-16 rounded-sm border flex-shrink-0
               ${i === 0 ? 'bg-neon-400 border-neon-400 text-black' : 'bg-dark-800 border-dark-700 text-gray-500'}`}>
               <span className="text-[10px] uppercase font-bold">{['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][(new Date().getDay() + i) % 7]}</span>
               <span className="text-xl font-black">{d}</span>
               {i === 2 && <div className="w-1 h-1 bg-neon-400 rounded-full mt-1"></div>}
            </div>
         ))}
      </div>

      {/* Missions */}
      <MissionList />

      {/* Upcoming Classes */}
      <div>
         <div className="flex justify-between items-end mb-4">
            <h3 className="text-white font-bold uppercase tracking-wider text-sm">Live Classes</h3>
            <button className="text-[10px] text-neon-400 uppercase font-bold hover:underline">View Schedule</button>
         </div>
         <div className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar">
            {CLASSES.map((session) => (
               <div 
                  key={session.id} 
                  onClick={() => setSelectedClass(session)}
                  className="w-64 flex-shrink-0 bg-dark-900 border border-dark-700 cursor-pointer hover:border-neon-400 transition-colors group relative"
               >
                  <div className={`h-32 ${session.image} relative overflow-hidden`}>
                     <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors"></div>
                     <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-10 h-10 bg-neon-400 rounded-full flex items-center justify-center text-black">
                           <Play size={16} fill="currentColor" className="ml-0.5" />
                        </div>
                     </div>
                     <span className="absolute top-2 right-2 bg-black/80 text-white text-[9px] font-bold px-1.5 py-0.5 uppercase rounded-sm">
                        {session.duration}
                     </span>
                  </div>
                  <div className="p-3">
                     <h4 className="text-white font-bold uppercase text-sm truncate">{session.title}</h4>
                     <p className="text-[10px] text-gray-500 uppercase mt-1">{session.instructor} • {session.intensity}</p>
                  </div>
               </div>
            ))}
         </div>
      </div>

      {/* Tribes / Groups */}
      <div>
         <h3 className="text-white font-bold uppercase tracking-wider text-sm mb-4">Tribes</h3>
         <div className="grid grid-cols-1 gap-3">
            {TRIBES.map((tribe) => (
               <div key={tribe.id} className="bg-dark-800 border border-dark-700 p-4 flex items-center justify-between group hover:bg-dark-700 transition-colors">
                  <div className="flex items-center gap-4">
                     <div className={`w-12 h-12 ${tribe.image} flex items-center justify-center text-white/50`}>
                        <Users size={20} />
                     </div>
                     <div>
                        <h4 className="text-white font-bold uppercase text-sm">{tribe.name}</h4>
                        <p className="text-[10px] text-gray-500 uppercase tracking-widest">{tribe.members} Operatives</p>
                     </div>
                  </div>
                  <button className="text-neon-400 text-xs font-bold uppercase border border-neon-400 px-3 py-1 hover:bg-neon-400 hover:text-black transition-colors">
                     Join
                  </button>
               </div>
            ))}
         </div>
      </div>

      {selectedClass && <ClassPlayer session={selectedClass} onClose={() => setSelectedClass(null)} />}
    </div>
  );
};
