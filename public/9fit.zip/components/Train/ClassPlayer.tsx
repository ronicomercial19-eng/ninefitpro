import React, { useState } from 'react';
import { X, Play, Pause, Heart, Activity } from 'lucide-react';
import { ClassSession } from '../../types';

interface ClassPlayerProps {
  session: ClassSession;
  onClose: () => void;
}

export const ClassPlayer: React.FC<ClassPlayerProps> = ({ session, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col animate-fade-in">
       {/* Video Area Placeholder */}
       <div className="relative flex-1 bg-dark-800 flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=1470&auto=format&fit=crop')] bg-cover bg-center opacity-40"></div>
          
          <button 
             onClick={() => setIsPlaying(!isPlaying)}
             className="w-20 h-20 bg-neon-400/90 rounded-full flex items-center justify-center text-black hover:scale-110 transition-transform z-10"
          >
             {isPlaying ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" className="ml-1" />}
          </button>

          {/* Overlay HUD */}
          <div className="absolute top-0 left-0 w-full p-6 flex justify-between items-start bg-gradient-to-b from-black/80 to-transparent">
             <div>
                <h2 className="text-white font-bold uppercase text-lg">{session.title}</h2>
                <p className="text-neon-400 text-xs uppercase tracking-widest">{session.instructor} • {session.duration}</p>
             </div>
             <button onClick={onClose} className="text-white hover:text-neon-400"><X size={24} /></button>
          </div>

          <div className="absolute bottom-0 left-0 w-full p-6 bg-gradient-to-t from-black via-black/50 to-transparent space-y-4">
             {/* Timeline */}
             <div className="w-full h-1 bg-gray-700 rounded-full overflow-hidden">
                <div className="w-1/3 h-full bg-neon-400"></div>
             </div>
             
             {/* Stats Overlay */}
             <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                   <div className="flex items-center gap-2 text-red-500 font-bold">
                      <Heart size={20} className="fill-current animate-pulse" /> 142 BPM
                   </div>
                   <div className="flex items-center gap-2 text-orange-400 font-bold">
                      <Activity size={20} /> 320 Kcal
                   </div>
                </div>
                <span className="text-white font-mono text-sm">12:30 / {session.duration}</span>
             </div>
          </div>
       </div>
    </div>
  );
};
