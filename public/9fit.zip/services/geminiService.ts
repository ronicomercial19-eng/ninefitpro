import { GoogleGenAI } from "@google/genai";
import { AIInsight, DailyMission } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateGoalInsight = async (goal: string): Promise<AIInsight> => {
  if (!apiKey) {
    return {
      text: "9FIT AI requires an API key to fetch real-time data. Connect to start your journey.",
      sources: []
    };
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `The user's main fitness goal is: "${goal}". 
      Provide a short, high-impact, scientific fact or motivational insight (max 2 sentences) specifically about this goal based on the latest sports science.
      Maintain a mysterious, elite, and professional tone.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "Focus on consistency and intensity.";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    // Extract sources
    const sources = chunks
      .map(chunk => chunk.web ? { web: chunk.web } : null)
      .filter(Boolean) as { web: { uri: string; title: string } }[];

    return { text, sources };
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      text: "Your goal is set. Prepare for transformation.",
      sources: []
    };
  }
};

export const generateDailyMission = async (goal: string): Promise<DailyMission> => {
  if (!apiKey) {
    return {
      title: "Tactical Assessment",
      description: "Complete a 15-minute bodyweight circuit to calibrate your baseline.",
      xpReward: 100,
      type: 'workout'
    };
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Create a single daily fitness mission for a user with the goal: "${goal}".
      Return ONLY a JSON object with this structure:
      {
        "title": "Short catchy title (max 4 words)",
        "description": "One sentence actionable task description",
        "xpReward": integer between 50 and 200,
        "type": "workout" or "nutrition" or "mindset"
      }
      Do not include markdown formatting.`,
    });

    const text = response.text || "";
    // Clean up potential markdown code blocks
    const jsonStr = text.replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(jsonStr) as DailyMission;
  } catch (error) {
    console.error("Gemini Mission Error:", error);
    return {
      title: "Core Stability",
      description: "Hold a plank for 60 seconds total accumulation.",
      xpReward: 50,
      type: 'workout'
    };
  }
};
