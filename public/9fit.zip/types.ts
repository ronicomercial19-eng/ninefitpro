export enum AppView {
  SPLASH = 'SPLASH',
  LOGIN = 'LOGIN',
  ONBOARDING = 'ONBOARDING',
  DASHBOARD = 'DASHBOARD'
}

export interface UserProfile {
  email?: string;
  name?: string;
  goal?: string;
  experienceLevel?: string;
  availability?: number; // Days per week
  measurements?: {
    height?: number;
    weight?: number;
  };
  isPremium?: boolean;
  coins?: number;
}

export interface GroundingSource {
  web?: {
    uri: string;
    title: string;
  };
}

export interface AIInsight {
  text: string;
  sources: GroundingSource[];
}

export interface DailyMission {
  title: string;
  description: string;
  xpReward: number;
  type: 'workout' | 'nutrition' | 'mindset';
}

export interface DailyStats {
  xp: number;
  level: number;
  streak: number;
  caloriesBurned: number;
  workoutsCompleted: number;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  xp: number;
  completed: boolean;
  type: 'DAILY' | 'WEEKLY' | 'SEASON';
  locked?: boolean;
}

export interface SeasonTier {
  tier: number;
  reward: string;
  status: 'LOCKED' | 'UNLOCKED' | 'CLAIMED';
  isPremium: boolean;
}

export interface FeedPost {
  id: string;
  user: string;
  avatar: string;
  image: string; // URL or placeholder color
  caption: string;
  likes: number;
  timeAgo: string;
}

export interface LeaderboardUser {
  rank: number;
  name: string;
  xp: number;
  avatar: string;
  change: 'up' | 'down' | 'same';
}

export interface ClassSession {
  id: string;
  title: string;
  instructor: string;
  duration: string;
  intensity: 'Low' | 'Medium' | 'High';
  image: string; // Thumbnail color
}

export interface Tribe {
  id: string;
  name: string;
  members: number;
  image: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

export interface StoreItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: 'DIGITAL' | 'GEAR' | 'SUPPLEMENTS';
}
